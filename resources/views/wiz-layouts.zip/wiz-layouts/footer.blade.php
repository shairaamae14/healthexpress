 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="{{asset('wizard/js/jquery-1.11.1.min.js')}}"></script>
<script src="{{asset('wizard/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('wizard/js/jquery.backstretch.min.js')}}"></script>
<script src="{{asset('wizard/js/retina-1.1.0.min.js')}}"></script>
<script src="{{asset('wizard/js/scripts.js')}}"></script>
 <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

        