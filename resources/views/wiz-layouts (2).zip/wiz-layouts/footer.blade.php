 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="{{asset('wizard/js/jquery-1.11.1.min.js')}}"></script>
<script src="{{asset('wizard/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('wizard/js/jquery.backstretch.min.js')}}"></script>
<script src="{{asset('wizard/js/retina-1.1.0.min.js')}}"></script>
<script src="{{asset('wizard/js/scripts.js')}}"></script>

<!--   Core JS Files   -->
    <script src="{{asset('customer/assets/js/jquery.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('customer/assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('customer/assets/js/material.min.js')}}"></script>

    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="{{asset('customer/assets/js/nouislider.min.js')}}" type="text/javascript"></script>

    <!--  Plugin for the Datepicker, full documentation here: http://www.eyecon.ro/bootstrap-datepicker/ -->
    <script src="{{asset('customer/assets/js/bootstrap-datepicker.js')}}" type="text/javascript"></script>

    <!-- Control Center for Material Kit: activating the ripples, parallax effects, scripts from the example pages etc -->
    <script src="{{asset('customer/assets/js/material-kit.js')}}" type="text/javascript"></script>
 <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

        